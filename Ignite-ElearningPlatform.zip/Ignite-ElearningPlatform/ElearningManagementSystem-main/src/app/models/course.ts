export class Course 
{
    coursename : string = '';
    courseid : string = '';
    enrolleddate : string = '';
    instructorname : string = '';
    instructorinstitution : string = '';
    enrolledcount : string = '0';
    youtubeurl : string = '';
    websiteurl : string = '';
    coursetype : string = '';
    skilllevel : string = '';
    language : string = '';
    description : string  = '';

    constructor() {}

}