export class Enrollment 
{
    coursename : string = '';
    courseid : string = '';
    enrolleddate : string = '';
    enrolledusername : string = '';
    enrolleduserid : string = '';
    enrolledusertype : string = '';
    instructorname : string = '';
    instructorinstitution : string = '';
    enrolledcount : string = '';
    youtubeurl : string = '';
    websiteurl : string = '';
    coursetype : string = '';
    skilllevel : string = '';
    language : string = '';
    description : string  = '';

    constructor() {}
}